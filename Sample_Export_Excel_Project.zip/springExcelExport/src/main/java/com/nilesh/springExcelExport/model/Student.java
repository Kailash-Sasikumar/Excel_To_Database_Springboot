package com.nilesh.springExcelExport.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="students")
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long sid;
	@Column(name="name")
	private String sname;
	@Column(name="address")
	private String saddress;
	@Column(name="city")
	private String scity;
	@Column(name="pincode")
	private double spin;
	
	
	public Student(long sid, String sname, String saddress, String scity, double spin) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.saddress = saddress;
		this.scity = scity;
		this.spin = spin;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getSid() {
		return sid;
	}
	public void setSid(long sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	public double getSpin() {
		return spin;
	}
	public void setSpin(double spin) {
		this.spin = spin;
	}
	
	
	
}
