package com.nilesh.springExcelExport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringExcelExportApplicationTests {

	@Test
	void contextLoads() {
	}

}
